package com.document.management;

import com.document.management.entities.Document;
import com.document.management.entities.Users;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

import java.util.List;

@SpringBootApplication
public class ManagementApplication {

	public static void main(String[] args) {
//		SpringApplication.run(ManagementApplication.class, args);
		Users user1 = new Users("Preeti");
		Users user2 = new Users("Harry");

		user1.createDocument("this is my document");
		user1.createDocument("this is also my document, the second one");

		List<Document> documents = user1.getAllDocuments();
		for(Document document : documents) {
			System.out.println(document.getDocumentName());
		}

	}


}
