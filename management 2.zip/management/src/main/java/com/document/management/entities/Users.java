package com.document.management.entities;

import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import org.springframework.boot.autoconfigure.domain.EntityScan;

import java.util.*;

@Entity
public class Users {
    @Id
    Long id;
    String name;
    private List<Document> documents;
    private Long viewers;

    public Users(String name) {
        this.documents = new ArrayList<>();
        this.name = name;
    }

//    public Users(Long id, String name, List<Document> document, Long viewers) {
//
//        this.documents = "";
//
//    }

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public List<Document> createDocument(String documentName) {
        Document document = new Document(documentName);
        documents.add(document);
        return documents;
    }
    public void accessForEditing(Long userId, Long docId){
        Map<Long, Access> userWithAccess = new HashMap<>();
        for(Document document: this.documents) {
            if(document.getId() == docId) {
                userWithAccess.put(userId, Access.EDITOR);
                document.setUserWithAccess(userWithAccess);
                System.out.println("Access to edit is given :" + " " + userId);
            }
        }
    }

    public void accessForViewing(Long userId, Document document){

    }

    public List<Document> getAllDocuments() {
        return this.documents;
    }
}
