package com.document.management.entities;

public enum Access {
    EDITOR,
    OWNER,
    READER
}
