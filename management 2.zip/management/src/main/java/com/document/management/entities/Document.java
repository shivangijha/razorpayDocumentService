package com.document.management.entities;

import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.ManyToOne;

import java.util.Map;

@Entity
public class Document {
    @Id
    private Long id;
    private String documentName;
    private String documentInfo;
    Map<Long, Access> userWithAccess;

    public Map<Long, Access> getUserWithAccess() {
        return userWithAccess;
    }

    public void setUserWithAccess(Map<Long, Access> userWithAccess) {
        this.userWithAccess = userWithAccess;
    }

    public Document(){}

    public Document(String documentName) {

        this.documentName = documentName;
    }

    public Document(Long id, String documentName, String documentInfo) {
        this.id = id;
        this.documentName = documentName;
        this.documentInfo = documentInfo;

    }

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getDocumentName() {
        return documentName;
    }

    public void setDocumentName(String documentName) {
        this.documentName = documentName;
    }

    public String getDocumentInfo() {
        return documentInfo;
    }

//    public void setDocumentInfo(String documentInfo, ) {
        //check ownership
//        if(this.userWithAccess() Access.OWNER)
//    }


}
